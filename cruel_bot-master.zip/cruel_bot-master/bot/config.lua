do local _ = {
  enabled_plugins = {
    "gm",
"locks"
  },
  group  = {
    data = "bot/group.json"
  },
  sudo_users = {
    268021336,
    260446917,
    223404066
  },
robot = {
    306386341,
    0
  }
}
return _
end