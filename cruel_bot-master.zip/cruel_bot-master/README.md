# cruel_bot
The best source based on New tg-cli

آموزش نصب

```sh


git clone https://github.com/CRUELTM/cruel_bot.git


cd cruel_bot


chmod 777 ./run ; cd tg ; wget https://valtman.name/files/telegram-cli-1124 ; chmod 777 ./telegram-cli-1124; cd .. ; ./run


```
بعد از این کار از شما شماره تلفن میخواهد
بعد وارد نمودن شماره ربات لانچ خواهد شد

* نوشته شده بر اساس تی جی جدید
* قابلیت افزودن پلاگین
* غیر قابل ادیت فایل های اصلی
* هر پلاگینی که برای این سورس مینویسید باید اوپن شود
* برای دریافت جدید ترین پلاگین ها میتوانید به کانال تیم کرول مراجعه کنید
[CRUEL TEAM | کانال تیم کرول](https://telegram.me/cruel_team)

#دستورات
###locks
>!lock (links,edit,fwd,username,spam)
>>!lock links


###mutes
>!mute (all,photo,document,gif,audio,voice,video)
>>!mute all


###settings
>!settings


###promote and demote
>!promote  --by reply or id
>>!demote  --by reply or id

###set owner
>!setowner  --by reply or id


<h1>نوشته شده توسط اعضای تیم کرول</h1>
برنامه نویس اصلی : [😍● ოɨℓﾑの ●😍](https://telegram.me/my_Iove_fatemeh)
#تیم ما
[M.KH](https://telegram.me/IT_MKH)

[ค๓เг](https://telegram.me/This_Is_Amir)

[Negative](https://telegram.me/Negative)

[Haydra #Boy](https://telegram.me/HaydraBoy)

｡∵ * ❁ ๓คђlค ❁* ∵ ｡

🇸.🇴.🇱.🇹.🇦.🇳

ოძ.ɾεzმ

☜☆☞zคђгค☜☆☞
